import React from "react";

export default function Cart() {
  return <h1>Home Page</h1>;
}
