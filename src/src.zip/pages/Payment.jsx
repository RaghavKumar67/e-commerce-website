import React from "react";

export default function Payment() {
  return <h1>Home Page</h1>;
}
