import React from "react";
import { FaSearch, FaExchangeAlt, FaHeart, FaShoppingCart, FaUser } from "react-icons/fa";
import AllCategoriesDropdown from "./AllCategoriesDropdown";

export default function Header() {
  return (
    <header>
      {/* --- Top Bar --- */}
      <div className="bg-purple-50 border-b border-purple-200 text-sm">
        <div className="max-w-7xl mx-auto flex justify-between items-center px-4 py-2">
          {/* Left Links */}
          <div className="flex gap-6 text-gray-800">
            <a href="#" className="hover:text-purple-600">Account</a>
            <a href="#" className="hover:text-purple-600">Track Order</a>
            <a href="#" className="hover:text-purple-600">Support</a>
          </div>
          {/* Right Contact Info */}
          <div className="text-gray-800">
            Need help? Call us:{" "}
            <span className="text-pink-600 font-semibold">+ 00645 4568</span>
          </div>
        </div>
      </div>

      {/* --- Middle Section --- */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between gap-6">
          {/* Left: Logo */}
          <div className="flex items-center space-x-2 flex-shrink-0">
            {/* <img src="/images/logo.png" alt="ShopUs" className="h-10 w-auto" /> */}
            <h1 className="text-4xl font-bold">
              <span className="text-purple-600">Shop</span>
              <span className="text-yellow-500">Cart</span>
            </h1>
          </div>

          {/* Middle: Search Button */}
          <div className="flex-grow flex justify-end">
            <button className="bg-yellow-400 text-black p-3 rounded-full hover:bg-yellow-500">
              <FaSearch />
            </button>
          </div>

          {/* Right: Icons */}
          <div className="flex items-center space-x-6 text-gray-700">
            {/* <div className="flex items-center space-x-1 cursor-pointer">
              <FaExchangeAlt />
              <span>Compare</span>
              <span className="bg-purple-600 text-white text-xs px-1.5 rounded-full">3</span>
            </div> */}
            <div className="flex items-center space-x-2 cursor-pointer">
            <div className="relative">
            <FaHeart className="text-2xl" />
            <span className="absolute -top-2 -right-2 bg-purple-600 text-white text-xs px-1.5 rounded-full">
                2
            </span>
            </div>
            <span>Wishlist</span>
            </div>

            <div className="flex items-center space-x-2 cursor-pointer">
            <div className="relative">
            <FaShoppingCart className="text-2xl" />
            <span className="absolute -top-2 -right-2 bg-purple-600 text-white text-xs px-1.5 rounded-full">
                2
            </span>
            </div>
            <span>Cart</span>
            </div>


            {/* <div className="cursor-pointer">
              <FaUser />
            </div> */}
          </div>

          {/* Vendor Button */}
          <div className="flex-shrink-0">
            <button className="bg-yellow-400 text-black px-5 py-2 rounded-full hover:bg-yellow-500 font-medium">
             Shop Now
            </button>
          </div>
        </div>
      </div>

      {/* --- Purple Navigation Bar --- */}
      <div className="bg-purple-600">
        <div className="max-w-7xl mx-auto flex items-center justify-between px-4 py-3 text-white">
            {/* All Categories Dropdown on left */}
            <AllCategoriesDropdown />

            {/* Menu Links on right */}
            <nav className="flex space-x-6 font-medium">
            <a href="#" className="hover:text-yellow-300">Home</a>
            <a href="#" className="hover:text-yellow-300">Shop +</a>
            <a href="#" className="hover:text-yellow-300">Pages +</a>
            <a href="#" className="hover:text-yellow-300">About</a>
            <a href="#" className="hover:text-yellow-300">Blog</a>
            <a href="#" className="hover:text-yellow-300">User Dashboard</a>
            <a href="#" className="hover:text-yellow-300">Contact</a>
            </nav>
        </div>
        </div>

    </header>
  );
}
