import React from "react";

export default function Checkout() {
  return <h1>Home Page</h1>;
}
